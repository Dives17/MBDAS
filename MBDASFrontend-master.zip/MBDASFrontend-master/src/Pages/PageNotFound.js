import React from "react";

function PageNotFound() {
  return (
    <div className="text-center my-4 mx-4">
      <h3>Page You have reqested not found</h3>
    </div>
  );
}

export default PageNotFound;
